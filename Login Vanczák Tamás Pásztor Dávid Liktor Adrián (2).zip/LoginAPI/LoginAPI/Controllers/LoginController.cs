﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System;
using System.Web;
using LoginAPI.Models;

namespace LoginAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        [HttpPost]

        public IActionResult Login(string uname, string pwd, int Rank)
        {
            User user = new User();
            using (var context = new loginContext())
            {
                try
                {
                    List<User> talalat = new List<User>(context.Users.Where(f => f.Uname == uname));
                    if (talalat.Count > 0 && talalat[0].Active == true && talalat[0].Rank == 1)
                    {
                        bool talalt = false;
                        int index = 0;
                        int elemSzam = Program.LoggedInUsers.Count;
                       
                        while (!talalt && index < elemSzam)
                        {
                            if (Program.LoggedInUsers.ElementAt(index).Value.Uname == uname)
                            {
                                lock (Program.LoggedInUsers)
                                {
                                    Program.LoggedInUsers.Remove(Program.LoggedInUsers.ElementAt(index).Key);
                                }
                                talalt = true;
                            }
                            index++;
                        }
                        return Ok("Üdvözöljük az admin oldalon");
                    }
                    else if (talalat[0].Rank == 0)
                    {
                        return Ok("Üdvözüljük a felhasználó oldalon");
                    }

                    /*if (talalat.Count > 0 && talalat[0].Rank == 1)
                    {
                        bool talalt = false;
                        int index = 0;
                        int elemSzam = Program.LoggedInUsers.Count;

                        while (!talalt && index < elemSzam)
                        {
                            if (Program.LoggedInUsers.ElementAt(index).Value.Uname == uname)
                            {
                                lock (Program.LoggedInUsers)
                                {
                                    Program.LoggedInUsers.Remove(Program.LoggedInUsers.ElementAt(index).Key);
                                }
                                talalt = true;
                            }
                            index++;
                        }
                        var rank = 1;
                        if (Program.LoggedInUsers.ElementAt(rank).Value.Rank == 0)
                        {
                            return Ok("Üdvözöljük a felhasználók oldalon");
                        }
                        else if (Program.LoggedInUsers.ElementAt(rank).Value.Rank == 1)
                        {
                            return Ok("Üdvözöljük az admin oldalon");
                        }
                    }*/
                    else
                    {
                        return BadRequest("Hibás név/Inaktív felhasználó!");
                    }
                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
            }
            return Ok("Sikeres bejelentkezés");
        }
    }
}
