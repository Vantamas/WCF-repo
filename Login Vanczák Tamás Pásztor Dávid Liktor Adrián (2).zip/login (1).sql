-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2022. Dec 15. 11:19
-- Kiszolgáló verziója: 10.4.20-MariaDB
-- PHP verzió: 7.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `login`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `uname` varchar(25) COLLATE utf8_hungarian_ci NOT NULL,
  `email` varchar(40) COLLATE utf8_hungarian_ci NOT NULL,
  `pwd` varchar(50) COLLATE utf8_hungarian_ci NOT NULL,
  `fullname` varchar(40) COLLATE utf8_hungarian_ci NOT NULL,
  `active` tinyint(1) DEFAULT NULL,
  `rank` int(1) DEFAULT NULL,
  `ban` bit(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `users`
--

INSERT INTO `users` (`id`, `uname`, `email`, `pwd`, `fullname`, `active`, `rank`, `ban`) VALUES
(22, 'asd', 'aaaaa@gmail.com', 'asd123', 'Kis Nagy', 1, 0, b'1'),
(23, 'dsd', 'dsd', 'dsd', 'dsd', 1, 1, b'1'),
(24, 'dsd', 'dsd', 'dsd', 'dsd', 1, 1, b'1'),
(25, 'dsd', 'dsd', 'dsd', 'dsd', 1, 1, b'1'),
(26, 'sdgsdg', 'sdgv', 'sídsdsd', 'dsddsvydsb', 1, 1, b'1'),
(27, 'sdgsdg', 'sdgv', 'sídsdsd', 'dsddsvydsb', 1, 1, b'1'),
(36, 'h', 'h', 'h', 'h', 1, 1, b'1'),
(44, 'x', 'x', 'x', 'x', 1, 1, b'1');

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
